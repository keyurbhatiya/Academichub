class Bird:
    def __init__(self, name):
        self.name = name

    def speak(self):
        print(f"{self.name} chirps")

# List of different objects
animals = [Dog("Buddy"), Cat("Whiskers"), Bird("Tweety")]

# Iterate through the list and call the speak method
for animal in animals:
    animal.speak()
