class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.__balance = balance  # Private attribute

    def deposit(self, amount):
        self.__balance += amount

    def withdraw(self, amount):
        if amount <= self.__balance:
            self.__balance -= amount
        else:
            print("Insufficient funds")

    def get_balance(self):
        return self.__balance

# Create an object
account = BankAccount("Alice", 100)

# Access and modify the object's state using methods
account.deposit(50)
print(account.get_balance())  # Output: 150
account.withdraw(75)
print(account.get_balance())  # Output: 75

# Attempt to access the private attribute directly (not recommended)
# print(account.__balance)  # AttributeError
