class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        print(f"{self.name} says woof!")

class Cat(Animal):
    def speak(self):
        print(f"{self.name} says meow!")

# Create objects
dog = Dog("Buddy")
cat = Cat("Whiskers")

# Access inherited and overridden methods
dog.speak()  # Output: Buddy says woof!
cat.speak()  # Output: Whiskers says meow!
