from abc import ABC, abstractmethod

class Vehicle(ABC):
    @abstractmethod
    def start_engine(self):
        pass

class Car(Vehicle):
    def start_engine(self):
        print("Car engine started")

class Motorcycle(Vehicle):
    def start_engine(self):
        print("Motorcycle engine started")

# Create objects
car = Car()
motorcycle = Motorcycle()

# Access the abstract method implementation
car.start_engine()         # Output: Car engine started
motorcycle.start_engine()  # Output: Motorcycle engine started
