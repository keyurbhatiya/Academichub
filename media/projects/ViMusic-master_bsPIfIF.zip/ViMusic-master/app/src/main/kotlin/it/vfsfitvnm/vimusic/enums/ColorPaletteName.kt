package it.vfsfitvnm.vimusic.enums

enum class ColorPaletteName {
    Default,
    Dynamic,
    PureBlack
}
