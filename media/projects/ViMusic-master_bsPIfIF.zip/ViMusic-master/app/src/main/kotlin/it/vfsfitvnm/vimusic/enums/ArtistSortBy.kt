package it.vfsfitvnm.vimusic.enums

enum class ArtistSortBy {
    Name,
    DateAdded
}
